CREATE DATABASE  IF NOT EXISTS `admdams` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `admdams`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: admdams
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ionics_line`
--

DROP TABLE IF EXISTS `ionics_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ionics_line` (
  `id` int NOT NULL AUTO_INCREMENT,
  `line` varchar(45) DEFAULT NULL,
  `model_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ionics_line`
--

LOCK TABLES `ionics_line` WRITE;
/*!40000 ALTER TABLE `ionics_line` DISABLE KEYS */;
INSERT INTO `ionics_line` VALUES (1,'1','35'),(2,'1','36'),(3,'1','34'),(4,'1','37'),(5,'1','41'),(6,'1','43'),(7,'1','42'),(8,'1','44'),(9,'1','70'),(10,'1','3'),(11,'1','4'),(12,'1','5'),(13,'1','6'),(14,'1','7'),(15,'1','8'),(16,'1','71'),(17,'1','31'),(18,'1','32'),(19,'1','33'),(20,'1','64'),(21,'1','66'),(22,'1','72'),(23,'1','65'),(24,'2','35'),(25,'2','36'),(26,'2','34'),(27,'2','37'),(28,'2','41'),(29,'2','43'),(30,'2','42'),(31,'2','44'),(32,'2','70'),(33,'2','3'),(34,'2','4'),(35,'2','5'),(36,'2','6'),(37,'2','7'),(38,'2','8'),(39,'2','71'),(40,'2','31'),(41,'2','32'),(42,'2','33'),(43,'2','64'),(44,'2','66'),(45,'2','72'),(46,'2','65'),(47,'7','39'),(48,'7','38'),(49,'7','40'),(50,'7','13'),(51,'7','74'),(52,'7','73'),(53,'7','26'),(54,'7','29'),(55,'7','25'),(56,'7','27'),(57,'7','10'),(58,'7','9'),(59,'7','11'),(60,'7','28'),(61,'7','63'),(62,'7','59'),(63,'7','57'),(64,'7','60'),(65,'7','58'),(66,'7','56'),(67,'7','61'),(68,'7','55'),(69,'7','17'),(70,'7','22'),(71,'7','23'),(72,'7','16'),(73,'7','54'),(74,'7','67'),(75,'7','68'),(76,'7','69'),(77,'7','18'),(78,'7','30'),(79,'8','39'),(80,'8','38'),(81,'8','40'),(82,'8','13'),(83,'8','74'),(84,'8','73'),(85,'8','26'),(86,'8','29'),(87,'8','25'),(88,'8','27'),(89,'8','10'),(90,'8','9'),(91,'8','11'),(92,'8','28'),(93,'8','63'),(94,'8','59'),(95,'8','57'),(96,'8','60'),(97,'8','58'),(98,'8','56'),(99,'8','61'),(100,'8','55'),(101,'8','17'),(102,'8','22'),(103,'8','23'),(104,'8','16'),(105,'8','54'),(106,'8','67'),(107,'8','68'),(108,'8','69'),(109,'8','18'),(110,'8','30'),(111,'9','45'),(112,'9','46'),(113,'9','47'),(114,'9','48'),(115,'9','49'),(116,'9','50'),(117,'9','51'),(118,'9','21'),(119,'9','14'),(120,'9','15'),(121,'9','19'),(122,'9','52'),(123,'9','20'),(124,'9','30'),(125,'10','45'),(126,'10','46'),(127,'10','47'),(128,'10','48'),(129,'10','49'),(130,'10','50'),(131,'10','51'),(132,'10','21'),(133,'10','14'),(134,'10','15'),(135,'10','19'),(136,'10','52'),(137,'10','20'),(138,'10','30'),(139,'11','12'),(140,'11','24'),(141,'11','62'),(142,'11','53'),(143,'20','12'),(144,'20','24'),(145,'20','62'),(146,'20','53');
/*!40000 ALTER TABLE `ionics_line` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-08 21:34:10
